﻿#include "TCPClient.h"
#include <QDebug>
#include <QTimer>

//basic method connect(sender, &SenderClass::signal, receiver, &ReceiverClass::slot);
TCPServer::TCPServer(QObject *parent) : QObject(parent), tcpSocket(new QTcpSocket(this)) {
    connect(tcpSocket, &QTcpSocket::connected, this, &TCPServer::onConnected);
    connect(tcpSocket, &QTcpSocket::disconnected, this, &TCPServer::onDisconnected);
    connect(tcpSocket, &QTcpSocket::readyRead, this, &TCPServer::onDataReceived);
    connect(tcpSocket, &QTcpSocket::errorOccurred, this, &TCPServer::onError);
}

TCPServer::~TCPServer() {
    delete tcpSocket;
}

void TCPServer::connectToHost(const QString &host, quint16 port) {
    qDebug() << "Attempting to connect to host" << host << "on port" << port;
    if (tcpSocket->state() == QTcpSocket::UnconnectedState) {
        tcpSocket->connectToHost(host, port);
    } else {
        qDebug() << "Socket is not in unconnected state, current state:" << tcpSocket->state();
    }
}

void TCPServer::disconnectFromHost() {
    if (tcpSocket->state() == QTcpSocket::ConnectedState) {
        tcpSocket->disconnectFromHost();
    }
    tcpSocket->close();
}

void TCPServer::sendData(const QByteArray &data) {
    if (tcpSocket->state() == QTcpSocket::ConnectedState) {
        tcpSocket->write(data);
        if (!tcpSocket->waitForBytesWritten(1000)) {
            qDebug() << "Failed to write data to socket";
        }
    } else {
        qDebug() << "Attempt to send data while socket is not connected";
    }
}

void TCPServer::onConnected() {
    qDebug() << "Connected to host";
    emit connectionSuccessful();
}

void TCPServer::onDisconnected() {
    qDebug() << "Disconnected from host";
    emit disconnected();
}

void TCPServer::onDataReceived() {
    QByteArray data = tcpSocket->readAll();
    qDebug() << "Received data: " << data;
}

void TCPServer::onError(QAbstractSocket::SocketError socketError) {
    qDebug() << "Network error occurred:" << socketError << "with message:" << tcpSocket->errorString();
    emit connectionFailed(tcpSocket->errorString());
    QTimer::singleShot(5000, this, [this]() {
        if (!tcpSocket->isOpen()) {
            tcpSocket->abort();
            connectToHost(tcpSocket->peerName(), tcpSocket->peerPort());
        }
    });
}
