﻿#include "Joystick.h"
#include "SBUSEncoder.h"
#include <QDebug>
#include <QString>
#include <SDL.h>

Joystick::Joystick(QWidget *parent)
    : QMainWindow(parent), joystick(nullptr), tcpServer(new TCPServer(this)), udpServer(new UDPServer(this)), tcpConnected(false) {
    QWidget *centralWidget = new QWidget(this);
    QHBoxLayout *mainLayout = new QHBoxLayout(centralWidget);
    setCentralWidget(centralWidget);

    QVBoxLayout *leftLayout = new QVBoxLayout();
    QVBoxLayout *rightLayout = new QVBoxLayout();
    mainLayout->addLayout(leftLayout);
    mainLayout->addLayout(rightLayout);

    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &Joystick::readJoystick);
    timer->start(16);

    if (SDL_NumJoysticks() > 0) {
        joystick = SDL_JoystickOpen(0);
        if (!joystick) {
            qDebug() << "Failed to open joystick 0: " << SDL_GetError();
        }
    } else {
        qDebug() << "No joysticks found.";
    }

    const QString axisTitles[4] = {"Yaw", "Pitch", "Roll", "Throttle"};
    for (int i = 0; i < 4; ++i) {
        axisLabels[i] = new QLabel(axisTitles[i], this);
        leftLayout->addWidget(axisLabels[i]);

        axisBars[i] = new QProgressBar(this);
        axisBars[i]->setRange(1090, 1950);
        leftLayout->addWidget(axisBars[i]);
    }

    auto buttonsLayout = new QGridLayout();
    leftLayout->addLayout(buttonsLayout);
    for (int i = 0; i < 16; ++i) {
        buttonLabels[i] = new QLabel(QStringLiteral("Button %1: 1090").arg(i), this);
        buttonsLayout->addWidget(buttonLabels[i], i / 4, i % 4);
    }

    QLabel *outputLabel = new QLabel(QStringLiteral("Joystick Output:"), this);
    rightLayout->addWidget(outputLabel);

    QPlainTextEdit *outputDisplay = new QPlainTextEdit(this);
    outputDisplay->setReadOnly(true);
    rightLayout->addWidget(outputDisplay);

    QHBoxLayout *ipLayout = new QHBoxLayout();
    QLabel* ipLabel = new QLabel(QStringLiteral("IP Address:"), this);
    ipLayout->addWidget(ipLabel);
    ipInput = new QLineEdit(this);
    ipInput->setText("192.168.168.2");
    ipLayout->addWidget(ipInput);
    rightLayout->addLayout(ipLayout);

    QHBoxLayout *portLayout = new QHBoxLayout();
    QLabel* portLabel = new QLabel(QStringLiteral("Port:"), this);
    portLayout->addWidget(portLabel);
    portInput = new QLineEdit(this);
    portInput->setFixedWidth(188);
    portInput->setText("5000");
    portLayout->addWidget(portInput);
    rightLayout->addLayout(portLayout);

    connectButton = new QPushButton(QStringLiteral("Connect TCP"), this);
    connect(connectButton, &QPushButton::clicked, this, &Joystick::toggleTCPConnection);
    rightLayout->addWidget(connectButton);

    connect(tcpServer, &TCPServer::connectionSuccessful, this, &Joystick::onConnectionSuccessful);
    connect(tcpServer, &TCPServer::connectionFailed, this, &Joystick::onConnectionFailed);
    connect(tcpServer, &TCPServer::disconnected, this, &Joystick::onDisconnected);

    udpServer->bindSocket(QHostAddress::Any, 5000);

    connect(timer, &QTimer::timeout, this, [this, outputDisplay]() {
        QString output;
        for (int i = 0; i < 4; ++i) {
            output += QString("%1: %2\n").arg(axisLabels[i]->text()).arg(axisBars[i]->value());
        }
        outputDisplay->setPlainText(output);
    });

    dataTimer = new QTimer(this);
    connect(dataTimer, &QTimer::timeout, this, &Joystick::sendDataToServer);

    // Add radio buttons for mode selection
    modeLayout = new QHBoxLayout();
    japaneseModeButton = new QRadioButton(QStringLiteral("日本手"), this);
    americanModeButton = new QRadioButton(QStringLiteral("美國手"), this);
    japaneseModeButton->setChecked(true);

    modeLayout->addWidget(japaneseModeButton);
    modeLayout->addWidget(americanModeButton);
    rightLayout->addLayout(modeLayout);

    connect(japaneseModeButton, &QRadioButton::toggled, this, &Joystick::readJoystick);
    connect(americanModeButton, &QRadioButton::toggled, this, &Joystick::readJoystick);
}

Joystick::~Joystick() {
    if (joystick) {
        SDL_JoystickClose(joystick);
    }
    if (timer) {
        timer->stop();
    }
    if (dataTimer) {
        dataTimer->stop();
    }
}

void Joystick::readJoystick() {
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        if (tcpConnected) {
            if (event.type == SDL_JOYAXISMOTION) {
                _getAxis();
            } else if (event.type == SDL_JOYBUTTONDOWN || event.type == SDL_JOYBUTTONUP) {
                int button = event.jbutton.button;
                bool pressed = (event.jbutton.state == SDL_PRESSED);

                static int buttonStates[16] = {1950, 1090, 1950, 1090, 1090, 1090, 1090, 1090, 1950, 1090, 1090, 1090, 1090, 1090, 1090, 1090};
                if ((button >= 0 && button < 3) || button == 8 || button == 9) {
                    if (pressed) {
                        buttonStates[button] = (buttonStates[button] == 1950) ? 1090 : 1950;
                        joystickChannels[4] = buttonStates[button];
                        buttonLabels[button]->setText(QStringLiteral("Button %1: %2").arg(button).arg(buttonStates[button]));
                    }
                } else if (button >= 3 && button < 16) {
                    int mappedValue = pressed ? 1950 : 1090;
                    joystickChannels[4 + button] = mappedValue;
                    buttonLabels[button]->setText(QStringLiteral("Button %1: %2").arg(button).arg(mappedValue));
                }
            }
        }
    }
}

void Joystick::toggleTCPConnection() {
    if (tcpConnected) {
        tcpServer->disconnectFromHost();
        tcpConnected = false;
        connectButton->setText("Connect TCP");
        dataTimer->stop();
    } else {
        QString ip = ipInput->text();
        quint16 port = portInput->text().toUShort();
        tcpServer->connectToHost(ip, port);
        connectButton->setText("Disconnect TCP");
        tcpConnected = true;
        QByteArray data = "Connection Request";
        udpServer->sendData(data, QHostAddress(ip), port);
        dataTimer->start(1000);
    }
}

void Joystick::onConnectionSuccessful() {
    qDebug() << "TCP Connection Successful";
    dataTimer->start(1000);
}

void Joystick::onConnectionFailed(const QString &reason) {
    qDebug() << "TCP Connection Failed: " << reason;
    tcpConnected = false;
    dataTimer->stop();
}

void Joystick::onDisconnected() {
    qDebug() << "TCP Disconnected";
    tcpConnected = false;
    dataTimer->stop();
}

void Joystick::sendDataToServer() {
    if (tcpConnected) {
        qDebug() << "joystickChannels values:";
        for (int i = 0; i < 16; ++i) {
            if (joystickChannels[i] < 1090 || joystickChannels[i] > 1950) {
                qDebug() << "Channel" << i << "value out of range:" << joystickChannels[i];
            } else {
                qDebug() << "Channel" << i << "value:" << joystickChannels[i];
            }
        }

        std::vector<uint8_t> sbusVector = SBUSEncoder(joystickChannels);
        QByteArray sbusData(reinterpret_cast<const char*>(sbusVector.data()), sbusVector.size());
        qDebug() << "Sending SBUS data:" << sbusData.toHex();
        tcpServer->sendData(sbusData);
    }
}

int Joystick::mapValue(int value, int minInput, int maxInput, int minOutput, int maxOutput) {
    return (value - minInput) * (maxOutput - minOutput) / (maxInput - minInput) + minOutput;
}

void Joystick::_getAxis() {
    int pwmvalue;

    struct AxisConfig {
        int channel;
        int minPWM;
        int maxPWM;
    };

    AxisConfig axisConfigs[4];
    if (japaneseModeButton->isChecked()) {
        axisConfigs[0] = {3, 1090, 1950}; // Roll
        axisConfigs[1] = {1, 1950, 1090}; // Pitch
        axisConfigs[2] = {0, 1090, 1950}; // Throttle
        axisConfigs[3] = {2, 1950, 1090}; // Yaw
    } else {
        axisConfigs[0] = {0, 1090, 1950}; // Throttle
        axisConfigs[1] = {1, 1950, 1090}; // Pitch
        axisConfigs[2] = {2, 1090, 1950}; // Roll
        axisConfigs[3] = {3, 1950, 1090}; // Yaw
    }

    for (int j = 0; j < SDL_JoystickNumAxes(joystick); j++) {
        int value = SDL_JoystickGetAxis(joystick, j);

        pwmvalue = 1950 - (value + 32767) * (1950 - 1090) / (32767 + 32768);

        if (pwmvalue > 1800) {
            pwmvalue = 1950;
        } else if (pwmvalue < 1200) {
            pwmvalue = 1090;
        }

        joystickChannels[axisConfigs[j].channel] = pwmvalue;

        if (j < 4) {
            axisBars[j]->setValue(pwmvalue);
        }
    }
}
