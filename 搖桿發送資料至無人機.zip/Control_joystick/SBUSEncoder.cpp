﻿#include "SBUSEncoder.h"
#include <vector>
#include <cstdint>
#include <QDebug>
#include <QByteArray>

std::vector<uint8_t> SBUSEncoder(int channel[16]) {
    std::vector<uint8_t> sbusData(25, 0);
    sbusData[0] = 0x0F; // Start byte

    uint16_t channels[16];
    for (int i = 0; i < 16; ++i) {
        channels[i] = static_cast<uint16_t>(channel[i]);
    }

    sbusData[1]  = (channels[0] & 0x07FF);
    sbusData[2]  = (channels[0] >> 8) | ((channels[1] & 0x07FF) << 3);
    sbusData[3]  = (channels[1] >> 5) | ((channels[2] & 0x07FF) << 6);
    sbusData[4]  = (channels[2] >> 2);
    sbusData[5]  = (channels[2] >> 10) | ((channels[3] & 0x07FF) << 1);
    sbusData[6]  = (channels[3] >> 7) | ((channels[4] & 0x07FF) << 4);
    sbusData[7]  = (channels[4] >> 4) | ((channels[5] & 0x07FF) << 7);
    sbusData[8]  = (channels[5] >> 1);
    sbusData[9]  = (channels[5] >> 9) | ((channels[6] & 0x07FF) << 2);
    sbusData[10] = (channels[6] >> 6) | ((channels[7] & 0x07FF) << 5);
    sbusData[11] = (channels[7] >> 3);
    sbusData[12] = (channels[8] & 0x07FF);
    sbusData[13] = (channels[8] >> 8) | ((channels[9] & 0x07FF) << 3);
    sbusData[14] = (channels[9] >> 5) | ((channels[10] & 0x07FF) << 6);
    sbusData[15] = (channels[10] >> 2);
    sbusData[16] = (channels[10] >> 10) | ((channels[11] & 0x07FF) << 1);
    sbusData[17] = (channels[11] >> 7) | ((channels[12] & 0x07FF) << 4);
    sbusData[18] = (channels[12] >> 4) | ((channels[13] & 0x07FF) << 7);
    sbusData[19] = (channels[13] >> 1);
    sbusData[20] = (channels[13] >> 9) | ((channels[14] & 0x07FF) << 2);
    sbusData[21] = (channels[14] >> 6) | ((channels[15] & 0x07FF) << 5);
    sbusData[22] = (channels[15] >> 3);
    sbusData[23] = 0x00; // Flags
    sbusData[24] = 0x00; // Footer

    qDebug() << "SBUS Data:" << QByteArray(reinterpret_cast<const char*>(sbusData.data()), sbusData.size()).toHex();
    return sbusData;
}
