﻿#ifndef SBUSENCODER_H
#define SBUSENCODER_H

#include <vector>
#include <cstdint>

std::vector<uint8_t> SBUSEncoder(int channel[16]);

#endif
