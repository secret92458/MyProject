﻿#ifndef TCPCLIENT_H
#define TCPCLIENT_H

#include <QTcpSocket>
#include <QObject>

class TCPServer : public QObject {
    Q_OBJECT

public:
    explicit TCPServer(QObject *parent = nullptr);
    ~TCPServer();

    void connectToHost(const QString &host, quint16 port);
    void disconnectFromHost();
    void sendData(const QByteArray &data);

signals:
    void connectionSuccessful();
    void connectionFailed(QString reason);
    void disconnected();

private slots:
    void onConnected();
    void onDisconnected();
    void onDataReceived();
    void onError(QAbstractSocket::SocketError socketError);

private:
    QTcpSocket *tcpSocket;
};

#endif
