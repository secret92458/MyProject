﻿#ifndef JOYSTICK_H
#define JOYSTICK_H

#include <QMainWindow>
#include <SDL.h>
#include <QLabel>
#include <QProgressBar>
#include <QTimer>
#include <QPushButton>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QLineEdit>
#include <QPlainTextEdit>
#include <QRadioButton>
#include "TCPClient.h"
#include "UDPServer.h"

class Joystick : public QMainWindow {
    Q_OBJECT

public:
    explicit Joystick(QWidget *parent = nullptr);
    ~Joystick();

private slots:
    void readJoystick();
    void toggleTCPConnection();
    void onConnectionSuccessful();
    void onConnectionFailed(const QString &reason);
    void onDisconnected();
    void sendDataToServer();

private:
    SDL_Joystick* joystick;
    QTimer* timer;
    QLabel* buttonLabels[16];
    QLabel* axisLabels[4];
    QProgressBar* axisBars[4];
    QPushButton* connectButton;
    TCPServer* tcpServer;
    UDPServer* udpServer;
    bool tcpConnected;
    QLineEdit* ipInput;
    QLineEdit* portInput;
    QRadioButton* japaneseModeButton;
    QRadioButton* americanModeButton;
    QHBoxLayout* modeLayout;
    int mapValue(int value, int minInput, int maxInput, int minOutput, int maxOutput);
    QTimer* dataTimer;
    int joystickChannels[16];

    void _getAxis();
};

#endif // JOYSTICK_H
