﻿#include "Joystick.h"
#include <QApplication>
#include <SDL.h>
#include <QDebug>

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK) < 0) {
        qDebug() << "SDL could not initialize! SDL_Error: " << SDL_GetError();
        return -1;
    }

    if (SDL_NumJoysticks() < 1) {
        qDebug() << "No joysticks connected!";
    } else {
        qDebug() << "Number of joysticks connected: " << SDL_NumJoysticks();
    }

    Joystick mainWindow;
    mainWindow.show();

    int result = app.exec();
    SDL_Quit();
    return result;
}
