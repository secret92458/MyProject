﻿#include "UDPServer.h"

UDPServer::UDPServer(QObject *parent) : QObject(parent), udpSocket(new QUdpSocket(this)) {}

UDPServer::~UDPServer() {
    delete udpSocket;
}

void UDPServer::bindSocket(const QHostAddress &address, quint16 port) {
    udpSocket->bind(address, port);
}

void UDPServer::sendData(const QByteArray &data, const QHostAddress &host, quint16 port) {
    udpSocket->writeDatagram(data, host, port);
}
