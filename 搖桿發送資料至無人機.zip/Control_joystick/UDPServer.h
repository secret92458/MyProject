﻿#ifndef UDPSERVER_H
#define UDPSERVER_H

#include <QObject>
#include <QUdpSocket>
#include <QHostAddress>

class UDPServer : public QObject {
    Q_OBJECT

public:
    explicit UDPServer(QObject *parent = nullptr);
    ~UDPServer();
    void bindSocket(const QHostAddress &address, quint16 port);
    void sendData(const QByteArray &data, const QHostAddress &host, quint16 port);

private:
    QUdpSocket *udpSocket;
};

#endif // UDPSERVER_H
