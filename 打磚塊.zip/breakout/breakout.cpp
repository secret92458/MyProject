﻿#include "breakout.h"
#include <QPainter>
#include <QTimerEvent>
#include <QKeyEvent>
#include <QMessageBox>

Breakout::Breakout(QWidget *parent) : QWidget(parent), left(false), right(false), gameOver(false), gameWon(false) {
    setStyleSheet("background-color: black;");
    setFixedSize(B_WIDTH, B_HEIGHT);
    initGame();
}

Breakout::~Breakout() {
}

void Breakout::initGame() {
    paddle_x = B_WIDTH / 2 - PADDLE_WIDTH / 2;
    paddle_y = B_HEIGHT - 30;

    ball_x = B_WIDTH / 2;
    ball_y = B_HEIGHT / 2;
    ball_dx = 2;
    ball_dy = -2;

    int k = 0;
    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < 6; ++j) {
            bricks[k] = QRect(j * 50 + 30, i * 20 + 30, 40, 10);
            brickVisible[k] = true;
            k++;
        }
    }

    timerId = startTimer(DELAY);
}

void Breakout::paintEvent(QPaintEvent *event) {
    Q_UNUSED(event);

    QPainter qp(this);

    if (gameOver) {
        qp.setPen(Qt::white);
        qp.drawText(rect(), Qt::AlignCenter, "Game Over");
    } else if (gameWon) {
        qp.setPen(Qt::white);
        qp.drawText(rect(), Qt::AlignCenter, "You Won!");
    } else {
        qp.setBrush(Qt::blue);
        qp.drawRect(paddle_x, paddle_y, PADDLE_WIDTH, PADDLE_HEIGHT);

        qp.setBrush(Qt::red);
        qp.drawEllipse(ball_x, ball_y, BALL_SIZE, BALL_SIZE);

        for (int i = 0; i < N_OF_BRICKS; ++i) {
            if (brickVisible[i]) {
                qp.setBrush(Qt::green);
                qp.drawRect(bricks[i]);
            }
        }
    }
}

void Breakout::keyPressEvent(QKeyEvent *event) {
    int key = event->key();

    if (key == Qt::Key_Left) {
        left = true;
    }

    if (key == Qt::Key_Right) {
        right = true;
    }

    QWidget::keyPressEvent(event);
}

void Breakout::keyReleaseEvent(QKeyEvent *event) {
    int key = event->key();

    if (key == Qt::Key_Left) {
        left = false;
    }

    if (key == Qt::Key_Right) {
        right = false;
    }

    QWidget::keyReleaseEvent(event);
}

void Breakout::timerEvent(QTimerEvent *event) {
    Q_UNUSED(event);

    if (!gameOver && !gameWon) {
        moveObjects();
        checkCollision();
    }

    repaint();
}

void Breakout::moveObjects() {
    if (left && paddle_x > 0) {
        paddle_x -= 5;
    }

    if (right && paddle_x < B_WIDTH - PADDLE_WIDTH) {
        paddle_x += 5;
    }

    ball_x += ball_dx;
    ball_y += ball_dy;

    if (ball_x <= 0 || ball_x >= B_WIDTH - BALL_SIZE) {
        ball_dx = -ball_dx;
    }

    if (ball_y <= 0) {
        ball_dy = -ball_dy;
    }

    if (ball_y >= B_HEIGHT - BALL_SIZE) {
        gameOver = true;
    }
}

void Breakout::checkCollision() {
    if (ball_y + BALL_SIZE >= paddle_y && ball_x + BALL_SIZE >= paddle_x && ball_x <= paddle_x + PADDLE_WIDTH) {
        ball_dy = -ball_dy;
    }

    for (int i = 0; i < N_OF_BRICKS; ++i) {
        if (brickVisible[i]) {
            if (ball_y <= bricks[i].bottom() && ball_y + BALL_SIZE >= bricks[i].top() &&
                ball_x + BALL_SIZE >= bricks[i].left() && ball_x <= bricks[i].right()) {
                ball_dy = -ball_dy;
                brickVisible[i] = false;

                bool allBricksGone = true;
                for (int j = 0; j < N_OF_BRICKS; ++j) {
                    if (brickVisible[j]) {
                        allBricksGone = false;
                        break;
                    }
                }

                if (allBricksGone) {
                    gameWon = true;
                }
                break;
            }
        }
    }
}

void Breakout::resetGame() {
    initGame();
    gameOver = false;
    gameWon = false;
}
