﻿#ifndef BREAKOUT_H
#define BREAKOUT_H

#include <QWidget>
#include <QKeyEvent>
#include <QTimer>

class Breakout : public QWidget {
    Q_OBJECT

public:
    Breakout(QWidget *parent = nullptr);
    ~Breakout();

protected:
    void paintEvent(QPaintEvent *event) override;
    void keyPressEvent(QKeyEvent *event) override;
    void keyReleaseEvent(QKeyEvent *event) override;
    void timerEvent(QTimerEvent *event) override;

private:
    void initGame();
    void moveObjects();
    void checkCollision();
    void resetGame();

    static const int B_WIDTH = 300;
    static const int B_HEIGHT = 400;
    static const int PADDLE_WIDTH = 60;
    static const int PADDLE_HEIGHT = 10;
    static const int BALL_SIZE = 10;
    static const int N_OF_BRICKS = 30;
    static const int DELAY = 10;

    int timerId;
    int paddle_x;
    int paddle_y;
    int ball_x;
    int ball_y;
    int ball_dx;
    int ball_dy;
    bool left;
    bool right;
    bool gameOver;
    bool gameWon;

    QRect bricks[N_OF_BRICKS];
    bool brickVisible[N_OF_BRICKS];
};

#endif // BREAKOUT_H
