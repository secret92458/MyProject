﻿#ifndef SNAKEGAME_H
#define SNAKEGAME_H

#include <QWidget>
#include <QList>
#include <QPoint>

class SnakeGame : public QWidget {
    Q_OBJECT

public:
    SnakeGame(QWidget *parent = nullptr);
    ~SnakeGame();

protected:
    void paintEvent(QPaintEvent *event) override;
    void keyPressEvent(QKeyEvent *event) override;
    void timerEvent(QTimerEvent *event) override;

private:
    enum Direction { Up, Down, Left, Right };
    void initGame();
    void move();
    void checkCollision();
    void placeFood();
    void drawSnake(QPainter &qp);
    void drawFood(QPainter &qp);

    static const int B_WIDTH = 300;
    static const int B_HEIGHT = 300;
    static const int DOT_SIZE = 10;
    static const int ALL_DOTS = 900;
    static const int RAND_POS = 29;
    static const int DELAY = 140;

    int timerId;
    int dots;
    int food_x;
    int food_y;
    QList<QPoint> snake;
    Direction direction;
    bool inGame;
};

#endif // SNAKEGAME_H
