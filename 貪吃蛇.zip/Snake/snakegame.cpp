﻿#include "snakegame.h"
#include <QPainter>
#include <QTimerEvent>
#include <QKeyEvent>
#include <QRandomGenerator>

SnakeGame::SnakeGame(QWidget *parent) : QWidget(parent) {
    setStyleSheet("background-color: black;");
    setFixedSize(B_WIDTH, B_HEIGHT);
    initGame();
}

SnakeGame::~SnakeGame() {
}

void SnakeGame::initGame() {
    dots = 3;
    snake.clear();
    for (int i = 0; i < dots; ++i) {
        snake.append(QPoint(50 - i * DOT_SIZE, 50));
    }

    direction = Right;
    inGame = true;
    placeFood();
    timerId = startTimer(DELAY);
}

void SnakeGame::placeFood() {
    int r = QRandomGenerator::global()->bounded(RAND_POS);
    food_x = r * DOT_SIZE;

    r = QRandomGenerator::global()->bounded(RAND_POS);
    food_y = r * DOT_SIZE;
}

void SnakeGame::paintEvent(QPaintEvent *event) {
    Q_UNUSED(event);

    QPainter qp(this);

    if (inGame) {
        drawFood(qp);
        drawSnake(qp);
    } else {
        qp.setPen(Qt::white);
        qp.drawText(rect(), Qt::AlignCenter, "Game Over");
    }
}

void SnakeGame::drawSnake(QPainter &qp) {
    for (int i = 0; i < snake.size(); ++i) {
        qp.setBrush(Qt::green);
        qp.drawRect(snake[i].x(), snake[i].y(), DOT_SIZE, DOT_SIZE);
    }
}

void SnakeGame::drawFood(QPainter &qp) {
    qp.setBrush(Qt::red);
    qp.drawRect(food_x, food_y, DOT_SIZE, DOT_SIZE);
}

void SnakeGame::keyPressEvent(QKeyEvent *event) {
    int key = event->key();

    if (key == Qt::Key_Left && direction != Right) {
        direction = Left;
    }

    if (key == Qt::Key_Right && direction != Left) {
        direction = Right;
    }

    if (key == Qt::Key_Up && direction != Down) {
        direction = Up;
    }

    if (key == Qt::Key_Down && direction != Up) {
        direction = Down;
    }

    QWidget::keyPressEvent(event);
}

void SnakeGame::timerEvent(QTimerEvent *event) {
    Q_UNUSED(event);

    if (inGame) {
        checkCollision();
        move();
    }

    repaint();
}

void SnakeGame::move() {
    for (int i = dots - 1; i > 0; --i) {
        snake[i] = snake[i - 1];
    }

    if (direction == Left) {
        snake[0].rx() -= DOT_SIZE;
    }

    if (direction == Right) {
        snake[0].rx() += DOT_SIZE;
    }

    if (direction == Up) {
        snake[0].ry() -= DOT_SIZE;
    }

    if (direction == Down) {
        snake[0].ry() += DOT_SIZE;
    }
}

void SnakeGame::checkCollision() {
    // Check if the snake collides with itself
    for (int i = 1; i < dots; ++i) {
        if (snake[0] == snake[i]) {
            inGame = false;
        }
    }

    // Check if the snake collides with the walls
    if (snake[0].x() >= B_WIDTH || snake[0].x() < 0 ||
        snake[0].y() >= B_HEIGHT || snake[0].y() < 0) {
        inGame = false;
    }

    // Check if the snake eats the food
    if (snake[0] == QPoint(food_x, food_y)) {
        dots++;
        snake.append(QPoint());
        placeFood();
    }
}
