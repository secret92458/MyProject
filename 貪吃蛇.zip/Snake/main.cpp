﻿#include <QApplication>
#include "snakegame.h"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    SnakeGame window;
    window.setWindowTitle("Snake Game");
    window.show();

    return app.exec();
}
