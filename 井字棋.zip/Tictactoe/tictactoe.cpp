﻿#include "tictactoe.h"
#include <QMessageBox>

TicTacToe::TicTacToe(QWidget *parent) : QWidget(parent), xTurn(true), gameActive(true) {
    gridLayout = new QGridLayout(this);

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            buttons[i][j] = new QPushButton("");
            buttons[i][j]->setFixedSize(100, 100);
            buttons[i][j]->setFont(QFont("Arial", 24));
            connect(buttons[i][j], &QPushButton::clicked, this, &TicTacToe::handleButtonClick);
            gridLayout->addWidget(buttons[i][j], i, j);
        }
    }
}

TicTacToe::~TicTacToe() {
}

void TicTacToe::handleButtonClick() {
    QPushButton *button = qobject_cast<QPushButton*>(sender());
    if (!button || !gameActive || !button->text().isEmpty()) return;

    button->setText(xTurn ? "X" : "O");
    xTurn = !xTurn;

    checkWin();
}

void TicTacToe::checkWin() {
    const char *winner = nullptr;

    for (int i = 0; i < 3; ++i) {
        // Check rows
        if (buttons[i][0]->text() == buttons[i][1]->text() && buttons[i][1]->text() == buttons[i][2]->text() && !buttons[i][0]->text().isEmpty()) {
            winner = buttons[i][0]->text().toStdString().c_str();
        }
        // Check columns
        if (buttons[0][i]->text() == buttons[1][i]->text() && buttons[1][i]->text() == buttons[2][i]->text() && !buttons[0][i]->text().isEmpty()) {
            winner = buttons[0][i]->text().toStdString().c_str();
        }
    }

    // Check diagonals
    if (buttons[0][0]->text() == buttons[1][1]->text() && buttons[1][1]->text() == buttons[2][2]->text() && !buttons[0][0]->text().isEmpty()) {
        winner = buttons[0][0]->text().toStdString().c_str();
    }
    if (buttons[0][2]->text() == buttons[1][1]->text() && buttons[1][1]->text() == buttons[2][0]->text() && !buttons[0][2]->text().isEmpty()) {
        winner = buttons[0][2]->text().toStdString().c_str();
    }

    if (winner) {
        gameActive = false;
        QMessageBox::information(this, "Game Over", QString("%1 wins!").arg(winner));
        resetGame();
    } else {
        // Check for a draw
        bool draw = true;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                if (buttons[i][j]->text().isEmpty()) {
                    draw = false;
                    break;
                }
            }
        }
        if (draw) {
            gameActive = false;
            QMessageBox::information(this, "Game Over", "It's a draw!");
            resetGame();
        }
    }
}

void TicTacToe::resetGame() {
    xTurn = true;
    gameActive = true;
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            buttons[i][j]->setText("");
        }
    }
}
