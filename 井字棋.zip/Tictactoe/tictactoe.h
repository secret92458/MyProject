﻿#ifndef TICTACTOE_H
#define TICTACTOE_H

#include <QWidget>
#include <QGridLayout>
#include <QPushButton>

class TicTacToe : public QWidget {
    Q_OBJECT

public:
    TicTacToe(QWidget *parent = nullptr);
    ~TicTacToe();

private slots:
    void handleButtonClick();

private:
    void checkWin();
    void resetGame();

    QGridLayout *gridLayout;
    QPushButton *buttons[3][3];
    bool xTurn;
    bool gameActive;
};

#endif // TICTACTOE_H
